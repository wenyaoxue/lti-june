package com.seed.util;

import java.util.ArrayList;

public interface Certification {
	public ArrayList<String> getCerts();
}
