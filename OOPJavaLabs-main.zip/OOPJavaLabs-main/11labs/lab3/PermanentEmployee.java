package lab3;

import java.time.LocalDate;

public class PermanentEmployee extends Employee {

	public PermanentEmployee(String fn, String ln, double sal, int grd, LocalDate joined) {
		super(fn, ln, sal, grd, joined);
		// TODO Auto-generated constructor stub
	}

}
