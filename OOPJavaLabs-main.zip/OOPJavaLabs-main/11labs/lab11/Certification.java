package lab11;

import java.util.ArrayList;

public interface Certification {
	public ArrayList<String> getCerts();
}
