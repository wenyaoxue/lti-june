package lab10;

import java.util.ArrayList;

public interface Certification {
	public ArrayList<String> getCerts();
}
