package lab4;

import java.time.LocalDate;

public class TechnicalAssociateContr extends ContractEmployee {

	public TechnicalAssociateContr(String fn, String ln, double sal, int grd, LocalDate joined) {
		super(fn, ln, sal, grd, joined);
	}
}
