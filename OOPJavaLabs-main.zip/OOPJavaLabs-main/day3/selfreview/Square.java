package selfreview;

public class Square {
	int length;
	void display(int length) {
		this.length = length;
	}
	int calculateArea() {
		return length*length;
	}
}
