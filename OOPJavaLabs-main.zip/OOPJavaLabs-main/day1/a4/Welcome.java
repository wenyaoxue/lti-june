package a4;

public class Welcome {
	public static void main(String[] args) {
		System.out.println("Welcome to Object Oriented Programming: Day1 Session");
	}
}
