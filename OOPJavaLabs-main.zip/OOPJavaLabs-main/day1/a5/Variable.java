package a5;

public class Variable {
	public static void main(String[] args) {
//		int intVal;
		int intVal=1;
		float floatVal = 250.5f;
		double doubleVal = 2500.5;
		boolean boolVal = true;
		
		System.out.println("Integer\t:"+intVal+"\nFloat\t:"+floatVal+"\nDouble\t:"+doubleVal+"\nBoolean\t:"+boolVal);
	}
}
