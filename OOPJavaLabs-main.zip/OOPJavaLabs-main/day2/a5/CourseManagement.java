package a5;

public class CourseManagement {
	public static void main(String[] args) {
		Student student;
		student = new Student();		
		System.out.println("id="+student.getStudentId()+ "; type="+student.getStudentType());
	}
}
