package selfreview;

public class Demo {
	public static void main(String[] args) {
		if (true)
//		if (1) //can only use booleans, not integers
			System.out.println("True Block");
		else
			System.out.println("False Block");
	}
}
