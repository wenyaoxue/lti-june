package selfreview;

public class Example4 {
	public static void main(String[] args) {
		int intValOne = 5, intValTwo = 7;
		System.out.println(((intValTwo*2) % intValOne)); //14%5=4
		System.out.println(intValTwo % intValOne); //7%5 = 2
	}
}
