package a4;

public class answers {
	/*
	 * actors and activities
	 * student - apply for course, view marks, view attendance
	 * graduate student
	 * post graduate student
	 * hostelite
	 * day scholar
	 * faculty member
	 * admin staff - see list of courses, see list of lecturers, see list of students, allocate courses, register students to courses, login, see list of course-lecturer history, see student residential status
	 * semester
	 * course
	 * lecturer - get paid, update marks, mark attendance
	 * marked - project, assignment, internal test, semester end examination
	 * full time lecturer
	 * visiting member
	 * head of department - allocate courses to lecturers
	 * 
	 * relationships (generalization, specialization, includes)
	 * semester includes course
	 * generalization <---> specialization:
	 * student <--> graduate student/postgraduate student
	 * student <--> hostelite/dayscholar
	 * lecturer <--> full time lecturer/visiting member
	 * course includes lecturer, students (+ marked items <--> types & attendance)
	 */
}
