package review;

public class ClassA {
	public void methodOne(int i) {}
	public void methodTwo(int i) {}
	public static void methodThree(int i) {}
	public static void methodFour(int i) {}
}
class ClassB extends ClassA {
	public void methodOne(int i) {}
	public void methodTwo(int i) {}
	public static void methodThree(int i) {}
	public static void methodFour(int i) {}
}
