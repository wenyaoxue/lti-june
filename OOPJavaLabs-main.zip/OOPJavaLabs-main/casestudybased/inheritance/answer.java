package inheritance;

public class answer {
	/*
	 * Travel class
	 * attributes: source, destination, date, time, ticketdetails, travelClassType
	 * subclasses: flight, train, bus - each which implement setting travelClassType and calculating fees
	 * 
	 * Tours - not really efficient to use inheritance
	 * oneWay class attributes: destination, km, charge
	 * oneDay class attributes: startTime, busNum, locations, charge
	 * package class attributes: hotel, locations, schedule, numPersons
	 */
}
